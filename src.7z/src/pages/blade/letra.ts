export interface Letra {
  letra:string;
  visible:boolean
}
